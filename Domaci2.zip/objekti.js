var korpa = {
	SSD: 500,
	"Maticna ploca": 400,
};
console.log(korpa);
korpa.GPU = 100;
korpa.CDrom = 200;
korpa.FloppyDisk = 900;
console.log(korpa);
korpa["Ram memorija"] = 100;
korpa["HDD"] = 150;
korpa["Procesori"] = 600;
console.log(korpa);
