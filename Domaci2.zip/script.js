//indexi  0         1             2            3

var proizvodi = ["Maticna ploca", "Ram memorija", "SSD"];
console.log(proizvodi);
proizvodi[3] = "HDD";
proizvodi.push("GPU", "Floppy disk", "CD rom");
console.log(proizvodi);
proizvodi[2] = "Procesori";
console.log(proizvodi);
